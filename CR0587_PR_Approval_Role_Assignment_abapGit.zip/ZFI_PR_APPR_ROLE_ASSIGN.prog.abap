*&---------------------------------------------------------------------*
*& Report ZFI_PR_APPR_ROLE_ASSIGN
*&---------------------------------------------------------------------*
*& CR_0587 - Automatic PR Approval Role assignment
*&
*& Implements the FS "TII_FS_S2P_CR_0587_Automatic PR Approval Role
*& assignment.docx": for every Cost Center / Internal Order changed
*& (or created) on the selection date, determine the SAP User ID of
*& the Person Responsible / User Responsible, check whether that user
*& already holds the PR-approval role(s) required for the object's
*& Company Code (maintained in custom table ZFI_PR_APPR_ROLE), and -
*& unless running in test mode - assign any missing role(s) so the
*& approval workflow does not fail.
*&
*& Intended to run both online (ALV result list) and as a daily
*& background job (per FS: "Schedule a daily background job to run
*& the program"). The FS asks for the job step user to be SAP_WFRT -
*& that is a background-job scheduling setting (SM36/SM37), not
*& something this program can set on itself, so it is not encoded
*& here.
*&
*& ASSUMPTIONS (adjust to match the actual system - not verifiable
*& without a connected backend):
*&   - CSKS-VERAK is a HR position (PA0001-PLANS); the actual SAP User
*&     ID behind it is resolved via
*&     ZCL_HR_COMMON_UTILITY=>GET_USERID_EMAIL_PERNR_FR_POS. The exact
*&     parameter names of that method are assumed below (IV_PLANS /
*&     EV_BNAME) and should be checked against the real class.
*&   - CSKS-VERAK_USER and COAS-VERAA_USER already contain a SAP User
*&     ID (USR21-BNAME) directly, per the FS.
*&   - "Created or changed on a specific day" is sourced from the
*&     standard change-document tables CDHDR/CDPOS (object classes
*&     'KOSTL' and 'AUFTRAG'), since CSKS/AUFK master records do not
*&     carry their own last-changed timestamp. If this system instead
*&     has a Z-append with an explicit changed-on field, swap the
*&     logic in FORM get_changed_objects accordingly.
*&   - Custom table ZFI_PR_APPR_ROLE (BUKRS, AGR_NAME) - shipped
*&     alongside this report in the same package - must be populated
*&     with the required role(s) per Company Code before this report
*&     is of any use.
*&---------------------------------------------------------------------*
REPORT zfi_pr_appr_role_assign.

"----------------------------------------------------------------------
" Local structures purely to anchor the SELECT-OPTIONS types below
"----------------------------------------------------------------------
DATA: ls_csks_ref TYPE csks,
      ls_aufk_ref TYPE aufk.

"----------------------------------------------------------------------
" Selection screen
"----------------------------------------------------------------------
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
PARAMETERS:
  p_bukrs TYPE bukrs,                                " Company Code - optional
  p_cdate TYPE sy-datum DEFAULT sy-datum OBLIGATORY.  " Changed/created on
SELECT-OPTIONS:
  s_kostl FOR ls_csks_ref-kostl,                      " Cost Center   - optional
  s_aufnr FOR ls_aufk_ref-aufnr.                      " Internal Order- optional
SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.
PARAMETERS:
  p_test TYPE flag AS CHECKBOX DEFAULT 'X'.  " Test run - report only, assign nothing
SELECTION-SCREEN END OF BLOCK b2.

"----------------------------------------------------------------------
" Working types
"----------------------------------------------------------------------
TYPES: BEGIN OF ty_object,
         object_type  TYPE char2,     " 'CC' or 'IO'
         object_id    TYPE char12,    " KOSTL or AUFNR
         bukrs        TYPE bukrs,
         resp_role    TYPE char20,    " 'Person Resp.' / 'User Resp.'
         source_field TYPE char20,    " e.g. 'CSKS-VERAK'
         raw_value    TYPE char12,    " position (PLANS) or user id as read
       END OF ty_object.

TYPES: BEGIN OF ty_result,
         object_type          TYPE char2,
         object_id            TYPE char12,
         bukrs                TYPE bukrs,
         resp_role            TYPE char20,
         user_id              TYPE xubname,
         roles_required       TYPE string,
         roles_missing_before TYPE string,
         roles_assigned       TYPE string,
         status               TYPE char10,
         message              TYPE char100,
       END OF ty_result.

DATA:
  gt_objects       TYPE STANDARD TABLE OF ty_object,
  gt_results       TYPE STANDARD TABLE OF ty_result,
  gt_required_role TYPE STANDARD TABLE OF zfi_pr_appr_role.

START-OF-SELECTION.
  PERFORM get_required_roles.
  PERFORM get_changed_objects.
  PERFORM get_cost_centers.
  PERFORM get_internal_orders.
  PERFORM resolve_and_process.

END-OF-SELECTION.
  IF gt_results IS INITIAL.
    MESSAGE 'No Cost Centers / Internal Orders found for the given selection' TYPE 'S' DISPLAY LIKE 'W'.
  ELSE.
    PERFORM display_alv.
  ENDIF.

*&---------------------------------------------------------------------*
*&      Form  GET_REQUIRED_ROLES
*&---------------------------------------------------------------------*
FORM get_required_roles.
  SELECT * FROM zfi_pr_appr_role
    INTO TABLE gt_required_role
    WHERE bukrs = p_bukrs OR p_bukrs = space.
ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_CHANGED_OBJECTS
*&---------------------------------------------------------------------*
*& Builds range tables of KOSTL / AUFNR changed (incl. created) on
*& P_CDATE, sourced from the standard change-document tables.
*&---------------------------------------------------------------------*
DATA: gr_kostl_changed TYPE RANGE OF kostl,
      gr_aufnr_changed TYPE RANGE OF aufnr.

FORM get_changed_objects.

  DATA: lt_cdhdr TYPE STANDARD TABLE OF cdhdr.

  " Cost Centers: change documents are logged under object class 'KOSTL',
  " OBJECTID = KOKRS(4) + KOSTL(10).
  SELECT * FROM cdhdr
    INTO TABLE lt_cdhdr
    WHERE objectclas = 'KOSTL'
      AND udate      = p_cdate.

  LOOP AT lt_cdhdr INTO DATA(ls_cdhdr).
    APPEND VALUE #( sign = 'I' option = 'EQ' low = ls_cdhdr-objectid+4(10) ) TO gr_kostl_changed.
  ENDLOOP.

  " Internal Orders: change documents are logged under object class 'AUFTRAG',
  " OBJECTID = AUFNR(12).
  CLEAR lt_cdhdr.
  SELECT * FROM cdhdr
    INTO TABLE lt_cdhdr
    WHERE objectclas = 'AUFTRAG'
      AND udate      = p_cdate.

  LOOP AT lt_cdhdr INTO ls_cdhdr.
    APPEND VALUE #( sign = 'I' option = 'EQ' low = ls_cdhdr-objectid(12) ) TO gr_aufnr_changed.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_COST_CENTERS
*&---------------------------------------------------------------------*
FORM get_cost_centers.

  DATA: lt_csks TYPE STANDARD TABLE OF csks.

  SELECT * FROM csks
    INTO TABLE lt_csks
    WHERE kostl  IN s_kostl
      AND ( bukrs = p_bukrs OR p_bukrs = space )
      AND kostl  IN gr_kostl_changed.

  LOOP AT lt_csks INTO DATA(ls_csks).
    IF ls_csks-verak IS NOT INITIAL.
      APPEND VALUE ty_object(
        object_type  = 'CC'
        object_id    = ls_csks-kostl
        bukrs        = ls_csks-bukrs
        resp_role    = 'Person Resp.'
        source_field = 'CSKS-VERAK'
        raw_value    = ls_csks-verak ) TO gt_objects.
    ENDIF.

    IF ls_csks-verak_user IS NOT INITIAL.
      APPEND VALUE ty_object(
        object_type  = 'CC'
        object_id    = ls_csks-kostl
        bukrs        = ls_csks-bukrs
        resp_role    = 'User Resp.'
        source_field = 'CSKS-VERAK_USER'
        raw_value    = ls_csks-verak_user ) TO gt_objects.
    ENDIF.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  GET_INTERNAL_ORDERS
*&---------------------------------------------------------------------*
FORM get_internal_orders.

  DATA: lt_aufk TYPE STANDARD TABLE OF aufk,
        lt_coas TYPE STANDARD TABLE OF coas.

  SELECT * FROM aufk
    INTO TABLE lt_aufk
    WHERE aufnr IN s_aufnr
      AND ( bukrs = p_bukrs OR p_bukrs = space )
      AND aufnr IN gr_aufnr_changed.

  CHECK lt_aufk IS NOT INITIAL.

  SELECT * FROM coas
    INTO TABLE lt_coas
    FOR ALL ENTRIES IN lt_aufk
    WHERE aufnr = lt_aufk-aufnr.

  LOOP AT lt_aufk INTO DATA(ls_aufk).
    READ TABLE lt_coas INTO DATA(ls_coas) WITH KEY aufnr = ls_aufk-aufnr.
    IF sy-subrc = 0 AND ls_coas-veraa_user IS NOT INITIAL.
      APPEND VALUE ty_object(
        object_type  = 'IO'
        object_id    = ls_aufk-aufnr
        bukrs        = ls_aufk-bukrs
        resp_role    = 'User Resp.'
        source_field = 'COAS-VERAA_USER'
        raw_value    = ls_coas-veraa_user ) TO gt_objects.
    ENDIF.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  RESOLVE_AND_PROCESS
*&---------------------------------------------------------------------*
FORM resolve_and_process.

  DATA: lv_user_id TYPE xubname,
        ls_result  TYPE ty_result.

  LOOP AT gt_objects INTO DATA(ls_object).
    CLEAR: lv_user_id, ls_result.

    CASE ls_object-source_field.
      WHEN 'CSKS-VERAK'.
        " Person Responsible is a HR position - resolve to a SAP User ID.
        " NOTE: parameter names IV_PLANS / EV_BNAME are assumed and should
        " be checked against the actual class interface.
        TRY.
            CALL METHOD zcl_hr_common_utility=>get_userid_email_pernr_fr_pos
              EXPORTING
                iv_plans = ls_object-raw_value
              IMPORTING
                ev_bname = lv_user_id.
          CATCH cx_root.
            CLEAR lv_user_id.
        ENDTRY.
      WHEN OTHERS.
        " CSKS-VERAK_USER / COAS-VERAA_USER already hold a SAP User ID.
        lv_user_id = ls_object-raw_value.
    ENDCASE.

    ls_result-object_type = ls_object-object_type.
    ls_result-object_id   = ls_object-object_id.
    ls_result-bukrs       = ls_object-bukrs.
    ls_result-resp_role   = ls_object-resp_role.
    ls_result-user_id     = lv_user_id.

    IF lv_user_id IS INITIAL.
      ls_result-status  = 'ERROR'.
      ls_result-message = 'Could not determine SAP User ID'.
      APPEND ls_result TO gt_results.
      CONTINUE.
    ENDIF.

    PERFORM process_role_check
      USING    lv_user_id
               ls_object-bukrs
      CHANGING ls_result.

    APPEND ls_result TO gt_results.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  PROCESS_ROLE_CHECK
*&---------------------------------------------------------------------*
*& Compares the roles required for IV_BUKRS (custom table
*& ZFI_PR_APPR_ROLE) against the roles the user already has
*& (BAPI_USER_GET_DETAIL) and - unless P_TEST is set - assigns any
*& missing role(s) via BAPI_USER_ACTGROUPS_ASSIGN. Per the FS's own
*& warning, that BAPI overwrites the complete role list, so the
*& existing roles are always read first and the missing ones appended
*& to them rather than assigning the missing roles on their own.
*&---------------------------------------------------------------------*
FORM process_role_check
  USING    iv_user_id TYPE xubname
           iv_bukrs   TYPE bukrs
  CHANGING cs_result  TYPE ty_result.

  DATA: lt_activitygroups   TYPE STANDARD TABLE OF bapiagr,
        lt_activitygroups_x TYPE STANDARD TABLE OF bapiagr,
        lt_return           TYPE STANDARD TABLE OF bapiret2,
        ls_logondata        TYPE bapilogond,
        ls_defaults         TYPE bapidefaul,
        ls_address          TYPE bapiaddr3,
        lt_required         TYPE STANDARD TABLE OF agr_name,
        lt_missing          TYPE STANDARD TABLE OF agr_name,
        lv_required_str     TYPE string,
        lv_missing_str      TYPE string,
        lv_assigned_str     TYPE string.

  " ---- Required roles for this Company Code ----
  LOOP AT gt_required_role INTO DATA(ls_req) WHERE bukrs = iv_bukrs.
    APPEND ls_req-agr_name TO lt_required.
    lv_required_str = |{ lv_required_str }{ ls_req-agr_name } |.
  ENDLOOP.

  IF lt_required IS INITIAL.
    cs_result-status  = 'SKIPPED'.
    cs_result-message = |No required role maintained in ZFI_PR_APPR_ROLE for { iv_bukrs }|.
    RETURN.
  ENDIF.
  cs_result-roles_required = lv_required_str.

  " ---- Roles the user already has ----
  CALL FUNCTION 'BAPI_USER_GET_DETAIL'
    EXPORTING
      username      = iv_user_id
    IMPORTING
      logondata     = ls_logondata
      defaults      = ls_defaults
      address       = ls_address
    TABLES
      activitygroups = lt_activitygroups
      return         = lt_return.

  READ TABLE lt_return WITH KEY type = 'E' TRANSPORTING NO FIELDS.
  IF sy-subrc = 0.
    cs_result-status  = 'ERROR'.
    READ TABLE lt_return INTO DATA(ls_err_msg) WITH KEY type = 'E'.
    cs_result-message = ls_err_msg-message.
    RETURN.
  ENDIF.

  " ---- Determine which required roles are missing ----
  LOOP AT lt_required INTO DATA(lv_req_role).
    READ TABLE lt_activitygroups WITH KEY agr_name = lv_req_role TRANSPORTING NO FIELDS.
    IF sy-subrc <> 0.
      APPEND lv_req_role TO lt_missing.
      lv_missing_str = |{ lv_missing_str }{ lv_req_role } |.
    ENDIF.
  ENDLOOP.
  cs_result-roles_missing_before = lv_missing_str.

  IF lt_missing IS INITIAL.
    cs_result-status  = 'OK'.
    cs_result-message = 'All required roles already assigned'.
    RETURN.
  ENDIF.

  IF p_test = abap_true.
    cs_result-status  = 'TEST'.
    cs_result-message = 'Test run - role(s) not assigned'.
    RETURN.
  ENDIF.

  " ---- Assign missing role(s): existing + missing, never missing alone,
  "      since BAPI_USER_ACTGROUPS_ASSIGN replaces the full role list ----
  LOOP AT lt_activitygroups INTO DATA(ls_existing_agr).
    APPEND ls_existing_agr TO lt_activitygroups_x.
  ENDLOOP.
  LOOP AT lt_missing INTO DATA(lv_missing_role).
    APPEND VALUE bapiagr( agr_name = lv_missing_role ) TO lt_activitygroups_x.
    lv_assigned_str = |{ lv_assigned_str }{ lv_missing_role } |.
  ENDLOOP.

  CLEAR lt_return.
  CALL FUNCTION 'BAPI_USER_ACTGROUPS_ASSIGN'
    EXPORTING
      username       = iv_user_id
    TABLES
      activitygroups = lt_activitygroups_x
      return         = lt_return.

  READ TABLE lt_return WITH KEY type = 'E' TRANSPORTING NO FIELDS.
  IF sy-subrc = 0.
    cs_result-status  = 'ERROR'.
    READ TABLE lt_return INTO ls_err_msg WITH KEY type = 'E'.
    cs_result-message = ls_err_msg-message.
    RETURN.
  ENDIF.

  CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
    EXPORTING
      wait = abap_true.

  cs_result-roles_assigned = lv_assigned_str.
  cs_result-status         = 'ASSIGNED'.
  cs_result-message        = 'Missing role(s) assigned successfully'.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV
*&---------------------------------------------------------------------*
FORM display_alv.

  DATA: lo_alv    TYPE REF TO cl_salv_table,
        lo_cols   TYPE REF TO cl_salv_columns_table,
        lo_column TYPE REF TO cl_salv_column_table,
        lx_msg    TYPE REF TO cx_salv_msg.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_alv
        CHANGING  t_table      = gt_results ).

      lo_alv->get_functions( )->set_all( abap_true ).

      lo_cols = lo_alv->get_columns( ).
      lo_cols->set_optimize( abap_true ).

      TRY.
          lo_column ?= lo_cols->get_column( 'OBJECT_TYPE' ).
          lo_column->set_long_text( 'Object Type (CC/IO)' ).

          lo_column ?= lo_cols->get_column( 'OBJECT_ID' ).
          lo_column->set_long_text( 'Cost Center / Order' ).

          lo_column ?= lo_cols->get_column( 'BUKRS' ).
          lo_column->set_long_text( 'Company Code' ).

          lo_column ?= lo_cols->get_column( 'RESP_ROLE' ).
          lo_column->set_long_text( 'Responsible Type' ).

          lo_column ?= lo_cols->get_column( 'USER_ID' ).
          lo_column->set_long_text( 'SAP User ID' ).

          lo_column ?= lo_cols->get_column( 'ROLES_REQUIRED' ).
          lo_column->set_long_text( 'Roles Required' ).

          lo_column ?= lo_cols->get_column( 'ROLES_MISSING_BEFORE' ).
          lo_column->set_long_text( 'Roles Missing (before run)' ).

          lo_column ?= lo_cols->get_column( 'ROLES_ASSIGNED' ).
          lo_column->set_long_text( 'Roles Assigned (this run)' ).

          lo_column ?= lo_cols->get_column( 'STATUS' ).
          lo_column->set_long_text( 'Status' ).

          lo_column ?= lo_cols->get_column( 'MESSAGE' ).
          lo_column->set_long_text( 'Message' ).

        CATCH cx_salv_not_found ##NO_HANDLER.
      ENDTRY.

      lo_alv->display( ).

    CATCH cx_salv_msg INTO lx_msg.
      MESSAGE lx_msg->get_text( ) TYPE 'E'.
  ENDTRY.

ENDFORM.
