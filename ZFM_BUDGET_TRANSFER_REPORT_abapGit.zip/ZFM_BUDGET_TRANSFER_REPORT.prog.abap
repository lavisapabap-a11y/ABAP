*&---------------------------------------------------------------------*
*& Report ZFM_BUDGET_TRANSFER_REPORT
*&---------------------------------------------------------------------*
*& FM Budget Transfer Report - classic selection-screen / ALV report.
*&
*& Implements the FS "FM Budget Transfer Report" (see FS.docx in the
*& repo root). This is the GUI-report counterpart of the RAP/CDS
*& implementation shipped separately as RAP_FundsTransferReport.zip -
*& both follow the exact same business logic (amount sign handling,
*& Company Code derivation/validation, Commitment Item Group lookup),
*& re-expressed here as a single executable program for SE38/SA38.
*&
*& ASSUMPTIONS (adjust to match the actual system's table definitions -
*& these are the same assumptions used by the CDS implementation):
*&   - FMBL primary key : FM_AREA, FISCYEAR, DOCNR, ITEM
*&   - FMBH primary key : FM_AREA, FISCYEAR, DOCNR
*&   - FMBH-PROCESS_UI domain values are 'SEND' / 'RECV'
*&   - FMBL-CMMTITEM maps directly to SKA1-SAKNR
*&   - FMBL-MEASURE maps directly to AUFK-AUFNR (Internal Order)
*&   - Commitment Item Group FM Set class is '0F02'
*&---------------------------------------------------------------------*
REPORT zfm_budget_transfer_report.

"----------------------------------------------------------------------
" Local structures purely to anchor the SELECT-OPTIONS types below
" (no database access happens against these).
"----------------------------------------------------------------------
DATA: ls_fmbl_ref TYPE fmbl.

"----------------------------------------------------------------------
" Selection screen (per FS "selection screen filters" table)
"----------------------------------------------------------------------
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
PARAMETERS:
  p_bukrs  TYPE bukrs   OBLIGATORY,   " Company Code   - mandatory, single
  p_fiscyr TYPE gjahr   OBLIGATORY,   " Fiscal Year    - mandatory, single
  p_fmarea TYPE fm_area OBLIGATORY.   " FM Area        - mandatory, single

SELECT-OPTIONS:
  s_fund   FOR ls_fmbl_ref-fund   ,    " Fund             - optional, multi
  s_fmctr  FOR ls_fmbl_ref-fundsctr,   " Funds Center     - optional, multi
  s_measr  FOR ls_fmbl_ref-measure.    " Internal Order/FP- optional, multi
SELECTION-SCREEN END OF BLOCK b1.

"----------------------------------------------------------------------
" Output structure - 1:1 with the FS report-column list
"----------------------------------------------------------------------
TYPES: BEGIN OF ty_output,
         request_number    TYPE bued_docnr,       " #1  Request Number
         process_type       TYPE buku_process_ui,  " #2  Type (Process)
         entity             TYPE bukrs,            " #3  Entity
         funds_center       TYPE fmfctr,            " #4  Unit (CC)/RC - Funds Center
         commitment_item    TYPE fmcit,             " #5  Acc. No. - Commitment Item
         commitment_it_desc TYPE char20,            " #6  Commitment Item Description
         internal_order     TYPE fmfprog,           " #7  Internal Order
         io_description      TYPE char40,            " #8  IO Description
         commitment_it_group TYPE char24,            " #9  Commitment Item Group
         from_amount        TYPE fmbltval,          " #10 From Amount
         to_amount          TYPE fmbltval,          " #11 To Amount
         net_transfer       TYPE fmbltval,          " #12 Net Transfer
         explanation        TYPE bued_hdtext,       " #13 Explanation
         approval_status    TYPE bued_docstate,     " #14 Approval Status
         fiscal_month       TYPE numc2,             " #15 Month
         currency           TYPE waers,
       END OF ty_output.

DATA: gt_output TYPE STANDARD TABLE OF ty_output.

"----------------------------------------------------------------------
" Working internal tables for source / master data
"----------------------------------------------------------------------
DATA:
  gt_fmbl      TYPE STANDARD TABLE OF fmbl,
  gt_fmbh      TYPE STANDARD TABLE OF fmbh,
  gt_fmfctr    TYPE STANDARD TABLE OF fmfctr,
  gt_ska1      TYPE STANDARD TABLE OF ska1,
  gt_aufkt     TYPE STANDARD TABLE OF aufkt,
  gt_setleaf   TYPE STANDARD TABLE OF setleaf,
  gt_setheader TYPE STANDARD TABLE OF setheader,
  gs_fmctr     TYPE fmctr.

START-OF-SELECTION.
  PERFORM select_data.
  PERFORM process_data.

END-OF-SELECTION.
  IF gt_output IS INITIAL.
    MESSAGE 'No records found for the given selection' TYPE 'S' DISPLAY LIKE 'W'.
  ELSE.
    PERFORM display_alv.
  ENDIF.

*&---------------------------------------------------------------------*
*&      Form  SELECT_DATA
*&---------------------------------------------------------------------*
FORM select_data.

  " Restricted per FS: BUDCAT = '9G', BUDTYPE = 'ZTRF'
  SELECT *
    FROM fmbl
    INTO TABLE gt_fmbl
    WHERE fm_area  = p_fmarea
      AND fiscyear = p_fiscyr
      AND budcat   = '9G'
      AND budtype  = 'ZTRF'
      AND fund     IN s_fund
      AND fundsctr IN s_fmctr
      AND measure  IN s_measr.

  CHECK gt_fmbl IS NOT INITIAL.

  SELECT *
    FROM fmbh
    INTO TABLE gt_fmbh
    FOR ALL ENTRIES IN gt_fmbl
    WHERE fm_area  = gt_fmbl-fm_area
      AND fiscyear = gt_fmbl-fiscyear
      AND docnr    = gt_fmbl-docnr.

  SELECT *
    FROM fmfctr
    INTO TABLE gt_fmfctr
    FOR ALL ENTRIES IN gt_fmbl
    WHERE fm_area  = gt_fmbl-fm_area
      AND fundsctr = gt_fmbl-fundsctr.

  " Company Code master used for the "Entity" display column.
  SELECT SINGLE * FROM fmctr INTO gs_fmctr WHERE bukrs = p_bukrs.

  SELECT *
    FROM ska1
    INTO TABLE gt_ska1
    FOR ALL ENTRIES IN gt_fmbl
    WHERE saknr = gt_fmbl-cmmtitem.

  SELECT *
    FROM aufkt
    INTO TABLE gt_aufkt
    FOR ALL ENTRIES IN gt_fmbl
    WHERE aufnr = gt_fmbl-measure
      AND spras = sy-langu.

  " Commitment Item Group: FM Set class '0F02', keyed by FM Area (SUBCLASS)
  SELECT *
    FROM setleaf
    INTO TABLE gt_setleaf
    WHERE setclass = '0F02'
      AND subclass  = p_fmarea.

  IF gt_setleaf IS NOT INITIAL.
    SELECT *
      FROM setheader
      INTO TABLE gt_setheader
      FOR ALL ENTRIES IN gt_setleaf
      WHERE setclass  = gt_setleaf-setclass
        AND subclass  = gt_setleaf-subclass
        AND shortname = gt_setleaf-shortname.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  PROCESS_DATA
*&---------------------------------------------------------------------*
FORM process_data.

  DATA: lv_total  TYPE fmbltval,
        ls_output TYPE ty_output.

  LOOP AT gt_fmbl INTO DATA(ls_fmbl).
    CLEAR ls_output.

    " ---- Derive Company Code from Fund Center master and validate ----
    READ TABLE gt_fmfctr INTO DATA(ls_fmfctr)
      WITH KEY fm_area  = ls_fmbl-fm_area
               fundsctr = ls_fmbl-fundsctr.
    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.

    IF ls_fmfctr-bukrs <> p_bukrs.
      " Company Code entered on selection screen does not match the
      " one derived from the Fund Center master - skip (per FS).
      CONTINUE.
    ENDIF.

    " ---- Header (Request Number, Process Type, Text, Status, Date) ----
    READ TABLE gt_fmbh INTO DATA(ls_fmbh)
      WITH KEY fm_area  = ls_fmbl-fm_area
               fiscyear = ls_fmbl-fiscyear
               docnr    = ls_fmbl-docnr.

    " ---- Amount calculation: total = sum of all 12 monthly values ----
    lv_total = ls_fmbl-tval01 + ls_fmbl-tval02 + ls_fmbl-tval03 + ls_fmbl-tval04
             + ls_fmbl-tval05 + ls_fmbl-tval06 + ls_fmbl-tval07 + ls_fmbl-tval08
             + ls_fmbl-tval09 + ls_fmbl-tval10 + ls_fmbl-tval11 + ls_fmbl-tval12.

    " ---- Send -> negative in From Amount, Receive -> positive in To Amount ----
    CASE ls_fmbh-process_ui.
      WHEN 'SEND'.
        ls_output-from_amount = -1 * abs( lv_total ).
        ls_output-to_amount   = 0.
      WHEN 'RECV'.
        ls_output-from_amount = 0.
        ls_output-to_amount   = abs( lv_total ).
      WHEN OTHERS.
        ls_output-from_amount = 0.
        ls_output-to_amount   = 0.
    ENDCASE.
    ls_output-net_transfer = abs( lv_total ).

    " ---- Commitment Item Description: SKA1-MCOD1 (G/L long text) ----
    READ TABLE gt_ska1 INTO DATA(ls_ska1) WITH KEY saknr = ls_fmbl-cmmtitem.
    IF sy-subrc = 0.
      ls_output-commitment_it_desc = ls_ska1-mcod1.
    ENDIF.

    " ---- Internal Order Description ----
    READ TABLE gt_aufkt INTO DATA(ls_aufkt) WITH KEY aufnr = ls_fmbl-measure.
    IF sy-subrc = 0.
      ls_output-io_description = ls_aufkt-ktext.
    ENDIF.

    " ---- Commitment Item Group (FM Set lookup) ----
    LOOP AT gt_setleaf INTO DATA(ls_leaf)
      WHERE valfrom <= ls_fmbl-cmmtitem
        AND valto   >= ls_fmbl-cmmtitem.

      READ TABLE gt_setheader INTO DATA(ls_header)
        WITH KEY setclass  = ls_leaf-setclass
                 subclass  = ls_leaf-subclass
                 shortname = ls_leaf-shortname.
      IF sy-subrc = 0.
        ls_output-commitment_it_group = ls_header-shortname.
      ENDIF.
      EXIT. " first matching range is sufficient
    ENDLOOP.

    " ---- Month, derived from the header posting date ----
    ls_output-fiscal_month = ls_fmbh-postdate+4(2).

    " ---- Remaining direct/derived fields ----
    ls_output-request_number = ls_fmbh-docnr.
    ls_output-process_type    = ls_fmbh-process_ui.
    ls_output-entity           = gs_fmctr-bukrs.
    ls_output-funds_center     = ls_fmbl-fundsctr.
    ls_output-commitment_item = ls_fmbl-cmmtitem.
    ls_output-internal_order  = ls_fmbl-measure.
    ls_output-explanation     = ls_fmbh-text50.
    ls_output-approval_status = ls_fmbh-docstate.
    ls_output-currency        = ls_fmbl-twaer.

    APPEND ls_output TO gt_output.
  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV
*&---------------------------------------------------------------------*
FORM display_alv.

  DATA: lo_alv    TYPE REF TO cl_salv_table,
        lo_cols   TYPE REF TO cl_salv_columns_table,
        lo_column TYPE REF TO cl_salv_column_table,
        lx_msg    TYPE REF TO cx_salv_msg.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_alv
        CHANGING  t_table      = gt_output ).

      lo_alv->get_functions( )->set_all( abap_true ).

      lo_cols = lo_alv->get_columns( ).
      lo_cols->set_optimize( abap_true ).

      TRY.
          lo_column ?= lo_cols->get_column( 'REQUEST_NUMBER' ).
          lo_column->set_short_text( 'Req. No.' ).
          lo_column->set_medium_text( 'Request Number' ).
          lo_column->set_long_text( 'Request Number' ).

          lo_column ?= lo_cols->get_column( 'PROCESS_TYPE' ).
          lo_column->set_long_text( 'Type (Process)' ).

          lo_column ?= lo_cols->get_column( 'ENTITY' ).
          lo_column->set_long_text( 'Entity' ).

          lo_column ?= lo_cols->get_column( 'FUNDS_CENTER' ).
          lo_column->set_long_text( 'Unit (CC) / RC - Funds Center' ).

          lo_column ?= lo_cols->get_column( 'COMMITMENT_ITEM' ).
          lo_column->set_long_text( 'Acc. No. - Commitment Item' ).

          lo_column ?= lo_cols->get_column( 'COMMITMENT_IT_DESC' ).
          lo_column->set_long_text( 'Commitment Item Description' ).

          lo_column ?= lo_cols->get_column( 'INTERNAL_ORDER' ).
          lo_column->set_long_text( 'Internal Order' ).

          lo_column ?= lo_cols->get_column( 'IO_DESCRIPTION' ).
          lo_column->set_long_text( 'IO Description' ).

          lo_column ?= lo_cols->get_column( 'COMMITMENT_IT_GROUP' ).
          lo_column->set_long_text( 'Commitment Item Group' ).

          lo_column ?= lo_cols->get_column( 'FROM_AMOUNT' ).
          lo_column->set_long_text( 'From Amount' ).

          lo_column ?= lo_cols->get_column( 'TO_AMOUNT' ).
          lo_column->set_long_text( 'To Amount' ).

          lo_column ?= lo_cols->get_column( 'NET_TRANSFER' ).
          lo_column->set_long_text( 'Net Transfer' ).

          lo_column ?= lo_cols->get_column( 'EXPLANATION' ).
          lo_column->set_long_text( 'Explanation' ).

          lo_column ?= lo_cols->get_column( 'APPROVAL_STATUS' ).
          lo_column->set_long_text( 'Approval Status' ).

          lo_column ?= lo_cols->get_column( 'FISCAL_MONTH' ).
          lo_column->set_long_text( 'Month' ).

        CATCH cx_salv_not_found ##NO_HANDLER.
      ENDTRY.

      lo_alv->display( ).

    CATCH cx_salv_msg INTO lx_msg.
      MESSAGE lx_msg->get_text( ) TYPE 'E'.
  ENDTRY.

ENDFORM.
