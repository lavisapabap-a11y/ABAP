@AbapCatalog.sqlViewName: 'ZIFMBUDTRANSF'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'FM Budget Transfer - Basic View'

//----------------------------------------------------------------------
// Basic interface view over FMBL (Budget document line items).
//
// Restrictions per FS:
//   - BUDCAT  = '9G'
//   - BUDTYPE = 'ZTRF'
//
// All FM master-data lookups (Fund Center master, Company Code,
// Commitment Item description, Internal Order description) are exposed
// as associations so the consumption view can pull in exactly the
// fields it needs and so Company Code derivation/validation can be
// done at the next layer.
//
// ASSUMPTIONS (adjust to match the actual system's table definitions):
//   - FMBL primary key   : FM_AREA, FISCYEAR, DOCNR, ITEM
//   - FMBH primary key   : FM_AREA, FISCYEAR, DOCNR
//   - MEASURE is assumed to reference an internal order (AUFK-AUFNR).
//     If Funded Programs can also be WBS elements, add a second
//     association to PRPS and COALESCE the description (see comment
//     at _OrderText below).
//----------------------------------------------------------------------
define view entity ZI_FMBudgetTransfer
  as select from fmbl as Transfer

  association [0..1] to fmbh   as _Header
    on  $projection.FmArea          = _Header.fm_area
    and $projection.FiscalYear      = _Header.fiscyear
    and $projection.DocumentNumber  = _Header.docnr

  association [0..1] to fmfctr as _FundsCenterMaster
    on  $projection.FmArea      = _FundsCenterMaster.fm_area
    and $projection.FundsCenter = _FundsCenterMaster.fundsctr

  association [0..1] to fmctr  as _CompanyCode
    on  $projection.CompanyCode = _CompanyCode.bukrs

  association [0..1] to ska1   as _GlAccount
    on  $projection.CommitmentItem = _GlAccount.saknr

  association [0..1] to aufkt  as _OrderText
    on  $projection.InternalOrder = _OrderText.aufnr
    and _OrderText.spras          = $session.system_language

{
      // ---- Keys (assumed FMBL primary key) ----
  key Transfer.fm_area          as FmArea,
  key Transfer.fiscyear         as FiscalYear,
  key Transfer.docnr            as DocumentNumber,
  key Transfer.item             as ItemNumber,

      // ---- Selection / grouping fields from FMBL ----
      Transfer.fund              as Fund,
      Transfer.fundsctr          as FundsCenter,
      Transfer.cmmtitem          as CommitmentItem,
      Transfer.measure           as InternalOrder,
      Transfer.budcat            as BudgetCategory,
      Transfer.budtype           as BudgetType,

      // ---- Derived Company Code, taken from the Fund Center master
      //      (FM Area + Fund Center -> Company Code). The consumption
      //      view compares this against the Company Code entered on
      //      the selection screen. ----
      _FundsCenterMaster.bukrs   as CompanyCode,

      // ---- Monthly values (raw; total/sign calculations happen in the
      //      consumption view so they can react to ProcessType) ----
      Transfer.tval01            as TVal01,
      Transfer.tval02            as TVal02,
      Transfer.tval03            as TVal03,
      Transfer.tval04            as TVal04,
      Transfer.tval05            as TVal05,
      Transfer.tval06            as TVal06,
      Transfer.tval07            as TVal07,
      Transfer.tval08            as TVal08,
      Transfer.tval09            as TVal09,
      Transfer.tval10            as TVal10,
      Transfer.tval11            as TVal11,
      Transfer.tval12            as TVal12,
      Transfer.twaer             as Currency,

      // ---- Header fields (Request Number, Process Type, Text, Status, Date) ----
      _Header.docnr              as RequestNumber,
      _Header.process_ui         as ProcessType,
      _Header.text50             as Explanation,
      _Header.docstate           as ApprovalStatus,
      _Header.postdate           as PostingDate,

      // ---- Entity / Company Code text for display (from FMCTR, keyed by
      //      the derived Company Code above) ----
      _CompanyCode.bukrs         as Entity,

      // ---- Descriptions ----
      _GlAccount.mcod1                 as CommitmentItemDescription,
      coalesce( _OrderText.ktext, '' ) as InternalOrderDescription,

      // ---- Associations exposed for further consumption ----
      _Header,
      _FundsCenterMaster,
      _CompanyCode,
      _GlAccount,
      _OrderText
}
where
      Transfer.budcat  = '9G'
  and Transfer.budtype = 'ZTRF'
