@AbapCatalog.sqlViewName: 'ZIFMCIGROUP'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Commitment Item -> FM Set Group Lookup'

//----------------------------------------------------------------------
// FM Sets store commitment-item groupings as SETHEADER (group header)
// + SETLEAF (individual values / value ranges) rather than a simple
// foreign key on FMBL, so this is modeled as its own lookup view
// joining SETLEAF to SETHEADER, restricted to commitment-item set
// class '0F02' (standard class for Commitment Item groups - adjust to
// the class actually used in the target system if different).
//----------------------------------------------------------------------
define view entity ZI_FMCmmtItemGroup
  as select from setleaf   as Leaf
  inner join     setheader as Header
    on  Leaf.setclass = Header.setclass
    and Leaf.subclass = Header.subclass
    and Leaf.shortname = Header.shortname
{
  key Leaf.subclass    as FmArea,
  key Leaf.valfrom     as CommitmentItemFrom,
      Leaf.valto       as CommitmentItemTo,
      Header.shortname as CommitmentItemGroup
}
where
  Leaf.setclass = '0F02'
