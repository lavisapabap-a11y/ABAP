CLASS zbp_fmbudgettransferreport DEFINITION
  PUBLIC
  ABSTRACT
  FINAL
  FOR BEHAVIOR OF zc_fmbudgettransferreport.

  " Read-only report: no CREATE/UPDATE/DELETE, no actions.
  " All selection, derivation, and calculation logic is implemented in:
  "   - ZI_FMBudgetTransfer          (basic view: joins, restrictions)
  "   - ZI_FMCmmtItemGroup           (FM Set lookup for Commitment Item Group)
  "   - ZC_FMBudgetTransferReport    (consumption view: parameters,
  "                                   Company Code validation, amount/
  "                                   sign logic, Net Transfer)
  " This class exists only to satisfy the "managed implementation in
  " class ..." requirement of the behavior definition; it has no
  " methods to implement because there are no operations to handle.

ENDCLASS.

CLASS zbp_fmbudgettransferreport IMPLEMENTATION.
ENDCLASS.
