# Service Binding

Service Bindings are generated through the ADT wizard (right-click
`ZSD_FMBudgetTransferReport` -> New Service Binding), not hand-written
source, so there's no source file to ship for it. Suggested settings:

| Setting            | Value                                   |
|--------------------|------------------------------------------|
| Name               | `ZSB_FMBUDGETTRANSFER`                    |
| Binding Type       | OData V4 - UI                             |
| Service Definition | `ZSD_FMBudgetTransferReport`               |

After creation, activate and use **Preview** to launch the generated
Fiori Elements List Report, which will present:

- Selection screen: Company Code, Fiscal Year, FM Area (mandatory),
  Fund, Fund Center, Internal Order (optional, multi-value)
- Result table: all 15 FS output columns, in the order defined in the
  metadata extension
