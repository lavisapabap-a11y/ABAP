@AbapCatalog.sqlViewName: 'ZCFMBUDTRANSF'
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'FM Budget Transfer Report'
@Search.searchable: true

//----------------------------------------------------------------------
// Consumption view = the actual report.
//
// Selection screen parameters (per FS):
//   P_BUKRS   Company Code   - single value  - mandatory
//   P_FISCYR  Fiscal Year    - single value  - mandatory
//   P_FMAREA  FM Area        - single value  - mandatory
//   Fund, Fund Center, Internal Order are optional / multi-value and
//   are therefore modeled as normal filterable elements
//   (@Consumption.filter with multipleSelections), not CDS parameters.
//
// Company Code validation logic (per FS):
//   "Read FMFCTR using FM Area + Fund Center -> derive Company Code.
//    Validate against Company Code entered on selection screen.
//    Display matching records in report output."
//   This is implemented as an INNER JOIN predicate against the derived
//   Company Code = :P_BUKRS, so a Fund Center whose master data maps to
//   a different Company Code is silently excluded, exactly as specified.
//
// Amount logic (per FS):
//   TotalAmount   = TVAL01 + ... + TVAL12
//   FromAmount    = TotalAmount as NEGATIVE, only for "Send" transactions
//   ToAmount      = TotalAmount as POSITIVE, only for "Receive" transactions
//   NetTransfer   = ABS(TotalAmount), always positive, for every record
//
//   ProcessType domain values are assumed to be 'SEND' / 'RECV' below -
//   replace with the actual domain fixed values used for FMBH-PROCESS_UI
//   in the target system (e.g. could be '1'/'2' or 'S'/'R').
//----------------------------------------------------------------------
define view entity ZC_FMBudgetTransferReport
  with parameters
    P_BUKRS  : bukrs,
    P_FISCYR : gjahr,
    P_FMAREA : fm_area

  as select from ZI_FMBudgetTransfer as Transfer

  left outer join ZI_FMCmmtItemGroup as Grouping
    on  Transfer.FmArea         = Grouping.FmArea
    and Transfer.CommitmentItem between Grouping.CommitmentItemFrom
                                 and     Grouping.CommitmentItemTo

{
      // ---- Selection screen echo fields (for display / debugging) ----
      @Consumption.filter.mandatory: true
      $parameters.P_BUKRS                            as SelectedCompanyCode,
      @Consumption.filter.mandatory: true
      $parameters.P_FISCYR                           as SelectedFiscalYear,
      @Consumption.filter.mandatory: true
      $parameters.P_FMAREA                           as SelectedFmArea,

      // ---- Optional / multi-value filters ----
      @Consumption.filter: { multipleSelections: true, mandatory: false }
      Transfer.Fund                                  as Fund,
      @Consumption.filter: { multipleSelections: true, mandatory: false }
      Transfer.FundsCenter                            as FundsCenter,
      @Consumption.filter: { multipleSelections: true, mandatory: false }
      Transfer.InternalOrder                          as InternalOrder,

      // ---- Report output columns (mapped 1:1 to the FS column list) ----
      @EndUserText.label: 'Request Number'
      Transfer.RequestNumber                          as RequestNumber,       // #1

      @EndUserText.label: 'Type (Process)'
      Transfer.ProcessType                             as ProcessType,         // #2

      @EndUserText.label: 'Entity'
      Transfer.Entity                                  as Entity,              // #3

      @EndUserText.label: 'Unit (CC) / RC - Funds Center'
      Transfer.FundsCenter                             as UnitFundsCenter,     // #4  (duplicate projection: filter field vs. display column)

      @EndUserText.label: 'Acc. No. - Commitment Item'
      Transfer.CommitmentItem                          as CommitmentItemNo,    // #5

      @EndUserText.label: 'Commitment Item Description'
      Transfer.CommitmentItemDescription               as CommitmentItemDesc,  // #6

      @EndUserText.label: 'Internal Order'
      Transfer.InternalOrder                           as InternalOrderNo,     // #7 (duplicate projection: filter field vs. display column)

      @EndUserText.label: 'IO Description'
      Transfer.InternalOrderDescription                 as IoDescription,       // #8

      @EndUserText.label: 'Commitment Item Group'
      Grouping.CommitmentItemGroup                      as CommitmentItemGroup, // #9

      // ---- Amount calculations ----
      @EndUserText.label: 'Total Amount (internal)'
      @Semantics.amount.currencyCode: 'Currency'
      (   Transfer.TVal01 + Transfer.TVal02 + Transfer.TVal03 + Transfer.TVal04
        + Transfer.TVal05 + Transfer.TVal06 + Transfer.TVal07 + Transfer.TVal08
        + Transfer.TVal09 + Transfer.TVal10 + Transfer.TVal11 + Transfer.TVal12 )
                                                          as TotalAmount,

      @EndUserText.label: 'From Amount'
      @Semantics.amount.currencyCode: 'Currency'
      case
        when Transfer.ProcessType = 'SEND' then
          -1 * abs(   Transfer.TVal01 + Transfer.TVal02 + Transfer.TVal03 + Transfer.TVal04
                    + Transfer.TVal05 + Transfer.TVal06 + Transfer.TVal07 + Transfer.TVal08
                    + Transfer.TVal09 + Transfer.TVal10 + Transfer.TVal11 + Transfer.TVal12 )
        else
          cast( 0 as fmbltval )
      end                                               as FromAmount,          // #10

      @EndUserText.label: 'To Amount'
      @Semantics.amount.currencyCode: 'Currency'
      case
        when Transfer.ProcessType = 'RECV' then
          abs(   Transfer.TVal01 + Transfer.TVal02 + Transfer.TVal03 + Transfer.TVal04
               + Transfer.TVal05 + Transfer.TVal06 + Transfer.TVal07 + Transfer.TVal08
               + Transfer.TVal09 + Transfer.TVal10 + Transfer.TVal11 + Transfer.TVal12 )
        else
          cast( 0 as fmbltval )
      end                                               as ToAmount,            // #11

      @EndUserText.label: 'Net Transfer'
      @Semantics.amount.currencyCode: 'Currency'
      abs(   Transfer.TVal01 + Transfer.TVal02 + Transfer.TVal03 + Transfer.TVal04
           + Transfer.TVal05 + Transfer.TVal06 + Transfer.TVal07 + Transfer.TVal08
           + Transfer.TVal09 + Transfer.TVal10 + Transfer.TVal11 + Transfer.TVal12 )
                                                          as NetTransfer,         // #12

      @EndUserText.label: 'Explanation'
      Transfer.Explanation                              as Explanation,         // #13

      @EndUserText.label: 'Approval Status'
      Transfer.ApprovalStatus                            as ApprovalStatus,      // #14

      @EndUserText.label: 'Month'
      @Semantics.calendar.month: true
      cast( substring( cast( Transfer.PostingDate as abap.char( 8 ) ), 5, 2 )
            as abap.numc( 2 ) )                          as Month,               // #15

      Transfer.Currency                                  as Currency
}
where
      // Mandatory selection-screen parameters drive the filter
      Transfer.FmArea      = $parameters.P_FMAREA
  and Transfer.FiscalYear  = $parameters.P_FISCYR

      // Company Code validation: only Fund Centers whose FMFCTR-derived
      // Company Code equals the Company Code entered on the selection
      // screen are shown - this implements "Validate against Company
      // Code entered on selection screen; display matching records".
  and Transfer.CompanyCode = $parameters.P_BUKRS
