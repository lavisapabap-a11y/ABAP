# FM Budget Transfer Report — RAP / CDS Implementation

Implements the Functional Specification `FS.docx` (source repo:
`lavisapabap-a11y/ABAP`). All selection, derivation, and calculation
logic lives in CDS views, per the FS instruction.

## Files

| File | Purpose |
|---|---|
| `cds/zi_fmbudgettransfer.ddl.asddls` | Basic view over `FMBL`, restricted to `BUDCAT = '9G'` / `BUDTYPE = 'ZTRF'`, with associations to `FMBH`, `FMFCTR`, `FMCTR`, `SKA1`, `AUFKT` |
| `cds/zi_fmcmmtitemgroup.ddl.asddls` | Lookup view resolving a Commitment Item to its FM Set (`SETHEADER`/`SETLEAF`) group |
| `cds/zc_fmbudgettransferreport.ddl.asddls` | Consumption view: selection parameters, Company Code validation, amount total/sign logic, Net Transfer |
| `cds/zc_fmbudgettransferreport.ddlx.asddlxs` | UI annotations (selection fields, list report columns, labels) |
| `behavior/zc_fmbudgettransferreport.bdef.asbdef` | Read-only RAP behavior definition |
| `behavior/zbp_fmbudgettransferreport.clas.abap` | Behavior implementation class (empty — no operations needed for a read-only report) |
| `service/zsd_fmbudgettransferreport.srvd.asrvd` | Service definition exposing the report |
| `service/service_binding_notes.md` | How to generate the Service Binding via ADT |

## FS requirement → implementation mapping

| FS requirement | Where it's implemented |
|---|---|
| Selection screen (Company Code, Fiscal Year, FM Area mandatory; Fund, Fund Center, Internal Order optional/multi) | `ZC_FMBudgetTransferReport` parameters `P_BUKRS`/`P_FISCYR`/`P_FMAREA` + `@Consumption.filter` elements |
| Read FMBL by Fiscal Year/FM Area/Fund/Fund Center/Internal Order, restricted to `BUDTYPE = 'ZTRF'` | `ZI_FMBudgetTransfer` WHERE clause + consumption-view filters |
| Obtain Fund Center from FMBL, read FMFCTR by FM Area + Fund Center, derive Company Code | `_FundsCenterMaster` association in `ZI_FMBudgetTransfer` |
| Validate derived Company Code against selection-screen value | `ZC_FMBudgetTransferReport` WHERE clause: `Transfer.CompanyCode = $parameters.P_BUKRS` |
| Restrict to `BUDCAT = '9G'` | `ZI_FMBudgetTransfer` WHERE clause |
| Commitment Item Description from `SKA1-MCOD1` | `_GlAccount` association |
| Total Amount = sum(TVAL01..TVAL12) | Calculated column in `ZC_FMBudgetTransferReport` |
| Send → negative, Receive → positive, Net Transfer always positive | `CASE`/`ABS()` expressions on `ProcessType` in `ZC_FMBudgetTransferReport` |
| Commitment Item Group | `ZI_FMCmmtItemGroup` (FM Set lookup) joined in the consumption view |
| Month (derived from posting date) | `SUBSTRING` on `PostingDate` in `ZC_FMBudgetTransferReport` |

## Assumptions to verify against the target system

These aren't discoverable from the FS text alone and should be
confirmed against the real data dictionary before activation:

1. **FMBL / FMBH key structure** — assumed `FM_AREA + FISCYEAR + DOCNR (+ ITEM)`.
2. **`PROCESS_UI` domain values** — assumed `'SEND'` / `'RECV'`; replace
   with the actual fixed values in the target system's domain for
   `BUKU_PROCESS_UI`.
3. **Commitment Item → G/L account link** — assumed `FMBL-CMMTITEM` maps
   directly to `SKA1-SAKNR`. If Commitment Items use a separate FMCI
   master, add an intermediate association instead.
4. **Internal Order description source** — assumed always `AUFK`/`AUFKT`
   (Order master). If `MEASURE` can also point to a WBS element, add a
   `PRPS`/`PRPS` text association and `COALESCE` the two.
5. **FM Set class for Commitment Item groups** — assumed `'0F02'`;
   confirm the class actually used for `SETHEADER-SETCLASS` in this
   system.

## Verification

No SAP system is available in this environment to activate/test these
objects. Please review the assumptions above, adjust field/table names
if they differ from your data dictionary, then activate in this order:
`ZI_FMBudgetTransfer` → `ZI_FMCmmtItemGroup` → `ZC_FMBudgetTransferReport`
→ `.ddlx` → `.bdef` → `ZBP_FMBUDGETTRANSFERREPORT` → `ZSD_...` →
Service Binding.
